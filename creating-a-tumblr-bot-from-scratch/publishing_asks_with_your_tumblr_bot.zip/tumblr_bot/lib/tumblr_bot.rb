require 'tumblr_client'
USERNAME = "doomybottest"

def post_a_thing

    # Authenticate via OAuth
    client = Tumblr::Client.new({
    :consumer_key => ENV['CONSUMER_KEY'],
    :consumer_secret => ENV['CONSUMER_SECRET'],
    :oauth_token => ENV['OAUTH_TOKEN'],
    :oauth_token_secret => ENV['OAUTH_TOKEN_SECRET']
    })

    asks = client.submissions(USERNAME, limit: 3)['posts']

    asks.each do |ask|
        # only answer asks (don't worry about submissions or fanmail)
        if ask['type'] != 'answer'
            return
        end

        response = "Hi #{ask['asking_name']}, #{ask['question'].split(' ').shuffle.join(' ')}"
        tags = "cool, stuff, vaporsoft"

        client.edit(USERNAME,
                    id: ask['id'],
                    answer: response,
                    state: 'published',
                    tags: tags)

    end   

end