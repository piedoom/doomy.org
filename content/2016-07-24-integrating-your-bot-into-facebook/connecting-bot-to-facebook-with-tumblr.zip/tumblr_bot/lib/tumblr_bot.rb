require 'tumblr_client'
require 'koala'

def post_a_thing

    # Authenticate via OAuth
    client = Tumblr::Client.new({
    :consumer_key => 'YOUR_KEYS_HERE',
    :consumer_secret => 'YOUR_KEYS_HERE',
    :oauth_token => 'YOUR_KEYS_HERE',
    :oauth_token_secret => 'YOUR_KEYS_HERE'
    })

    # Authenticate to Facebook
    facebook = Koala::Facebook::API.new('YOUR_KEYS_HERE')

    alignments = ["Lawful Good", 
                    "Neutral Good", 
                    "Chaotic Good", 
                    "Lawful Neutral",
                    "True Neutral",
                    "Chaotic Neutral",
                    "Lawful Evil",
                    "Neutral Evil",
                    "Chaotic Evil" ]

    adjectives = ["Cool", "Gamer", "Doctor", "Pathetic"]
    nouns = ["Boy", "Pineapple Ham", "Child", "Gluestick", "Muffin"]

    sentence = "#{alignments.sample}: #{adjectives.sample} #{nouns.sample}."

    # Make the request
    client.text("your_blog", title: sentence)
    facebook.put_wall_post(sentence)
end
